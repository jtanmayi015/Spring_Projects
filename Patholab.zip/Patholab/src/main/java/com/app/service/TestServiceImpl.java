package com.app.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.dto.TestDto;
import com.app.entities.Test;
import com.app.repository.TestRepository;
@Service
@Transactional
public class TestServiceImpl implements TestService {
	@Autowired
	  private TestRepository testRepo;
	@Autowired
	private ModelMapper mapper;
	@Override
	public String addTest(TestDto testDto) {
		
		Test test = mapper.map(testDto, Test.class);
		
		// You can perform any additional operations or validations here

		// Save the test to the repository
		testRepo.save(test);

		return test.getTestName() + " Added Successfully!";
	}
	 @Override
	    public void removeTests(Long testId) {
	        testRepo.deleteById(testId);
	    }
	 @Override
	    public List<TestDto> getAllTests() {
	        List<Test> tests = testRepo.findAll();
	        return tests.stream()
	                .map(test -> mapper.map(test, TestDto.class))
	                .collect(Collectors.toList());
	 }
	 @Override
	    public boolean updateTest(Long id, TestDto testDto) {
	        Optional<Test> optionalTest = testRepo.findById(id);
	        if (optionalTest.isPresent()) {
	            Test test = optionalTest.get();
	            // Update the test properties from testDto
	            test.setTestName(testDto.getTestName());
	            test.setTestPrice(testDto.getTestPrice());
	            // Save the updated test
	            testRepo.save(test);
	            return true;
	        }
	        return false;
	    }
}
