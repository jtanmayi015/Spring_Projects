package com.app.service;

import javax.validation.Valid;

import com.app.dto.EmployeeDto;

public interface EmployeeService {

	EmployeeDto addEmployee(EmployeeDto emp);

}
