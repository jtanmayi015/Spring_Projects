package com.app.service;

import java.time.LocalDate;

import javax.transaction.Transactional;
import javax.validation.Valid;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.custom_excceptions.ResourceNotFoundException;
import com.app.dto.PatientDto;
import com.app.entities.Employee;
import com.app.entities.Patient;
import com.app.repository.EmployeeRepository;
import com.app.repository.PatientRepository;
@Service
@Transactional
public class PatientServiceImpl implements PatientService {
	@Autowired
	private PatientRepository patientRepo;
	
	@Autowired
	private EmployeeRepository empRepo;
	
	@Autowired
	private ModelMapper mapper;
	
	@Override
	public String addPatientDetails(@Valid PatientDto patient) {
		Patient pat = mapper.map(patient, Patient.class);
		Long empId=patient.getEmpId();
		Employee emp=empRepo.findById(empId).orElseThrow(() -> new ResourceNotFoundException("Invalid Employee Id!!!!"));
		pat.setEmp(emp);
		LocalDate currentDate = LocalDate.now();
        pat.setCreatedOn(currentDate);
        pat.setModifyOn(currentDate);
        LocalDate dateOfBirth = pat.getDateOfBirth(); 
        pat.setDateOfBirth(dateOfBirth); 
        patientRepo.save(pat);
        
		return pat.getPatientFirstName() + " Added Successfully!";
	}

	
//	 
}
