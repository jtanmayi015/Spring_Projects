package com.app.service;

import javax.transaction.Transactional;
import javax.validation.constraints.NotNull;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.app.custom_excceptions.ResourceNotFoundException;
import com.app.dto.BillDto;
import com.app.entities.Bill;
import com.app.entities.Employee;
import com.app.entities.Patient;
import com.app.entities.Test;
import com.app.repository.BillRepository;
import com.app.repository.EmployeeRepository;
import com.app.repository.PatientRepository;
import com.app.repository.TestRepository;

@Service
@Transactional
public class BillServiceImpl implements BillService {
	@Autowired
    private  BillRepository billRepository;
	@Autowired
    private  PatientRepository patientRepository;
	@Autowired
    private  EmployeeRepository employeeRepository;
	@Autowired
    private TestRepository testRepository;
	@Autowired
    private  ModelMapper modelMapper;
   

    @Override
	public String addBillDetails(@NotNull Long patientId, @PathVariable @NotNull Long testId,
			@PathVariable @NotNull Long empId,BillDto billDto) {
		//validate emp
		Patient patient = patientRepository.findById(patientId)
				.orElseThrow(() -> new ResourceNotFoundException("Invalid Emp ID!!!"));
		Test test = testRepository.findById(patientId)
				.orElseThrow(() -> new ResourceNotFoundException("Invalid Emp ID!!!"));
		Employee emp = employeeRepository.findById(patientId)
				.orElseThrow(() -> new ResourceNotFoundException("Invalid Emp ID!!!"));
		
		// map dtp --> entity
		Bill bill = modelMapper.map(billDto, Bill.class);
		// establish un dir link , adr ---> emp
		bill.setPatientId(patient);
		// save adr details
		billRepository.save(bill);
		return "Assigned new bill , " 
		+ bill.getId();
	}
}
