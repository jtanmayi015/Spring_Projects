package com.app.service;

import org.springframework.validation.annotation.Validated;

import com.app.dto.PatientDto;

public interface PatientService {
 String addPatientDetails(@Validated PatientDto patient);


}
