package com.app.service;

import javax.validation.constraints.NotNull;

import com.app.dto.BillDto;
import com.app.entities.Bill;

public interface BillService {

	

	String addBillDetails(@NotNull Long patientId, @NotNull Long testId, @NotNull Long empId, BillDto billDto);

}
