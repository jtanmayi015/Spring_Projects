package com.app.service;

import javax.transaction.Transactional;
import javax.validation.Valid;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.dto.EmployeeDto;
import com.app.entities.Employee;
import com.app.repository.AdminRepository;
import com.app.repository.EmployeeRepository;

@Service
@Transactional
public class EmployeeServiceImpl implements EmployeeService {
	@Autowired
	private EmployeeRepository employeeRepo;
	@Autowired
	private AdminRepository adminRepo;
	@Autowired
	private ModelMapper mapper;
	@Override
    public EmployeeDto addEmployee(EmployeeDto employeeDTO) {
        // Set the adminId to 1 (assuming adminId is a field in EmployeeDTO)
        employeeDTO.setAdminId(1L);
        
        Employee employee = mapper.map(employeeDTO, Employee.class);
        // You can add any additional logic here before saving the employee
        Employee savedEmployee = employeeRepo.save(employee);
        return mapper.map(savedEmployee, EmployeeDto.class);
    }



}
