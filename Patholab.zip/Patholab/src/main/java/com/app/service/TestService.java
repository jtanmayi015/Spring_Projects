package com.app.service;

import java.util.List;

import com.app.dto.TestDto;
import com.app.entities.Test;

public interface TestService {

	String addTest(TestDto testDto);

	void removeTests(Long testId);

	List<TestDto> getAllTests();

	boolean updateTest(Long id, TestDto testDto);

}
