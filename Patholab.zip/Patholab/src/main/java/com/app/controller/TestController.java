package com.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.dto.ApiResponse;
import com.app.dto.TestDto;
import com.app.service.TestService;

@RestController
@RequestMapping("/tests")
public class TestController {
	private  TestService testService;
    
    @Autowired
    public TestController(TestService testService) {
        this.testService = testService;
    }

    @PostMapping
	public ResponseEntity<?> addTest(@RequestBody TestDto testDto) {
		try {
			String test = testService.addTest(testDto);
			return ResponseEntity.status(HttpStatus.CREATED).body(test);
		} catch (Exception e) {
			return new ResponseEntity<>(new ApiResponse(e.getMessage()), HttpStatus.NOT_FOUND);
		}
	}
    @DeleteMapping("/{testId}")
    public void removeTests(@PathVariable Long testId) {
        testService.removeTests(testId);
    }
    @GetMapping
    public ResponseEntity<List<TestDto>> getAllTests() {
        List<TestDto> tests = testService.getAllTests();
        return new ResponseEntity<>(tests, HttpStatus.OK);
    }
    @PutMapping("/{id}")
    public ResponseEntity<String> updateTest(@PathVariable Long id, @RequestBody TestDto testDto) {
        boolean updated = testService.updateTest(id, testDto);
        if (updated) {
            return new ResponseEntity<>("Test updated successfully", HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Test not found or couldn't be updated", HttpStatus.NOT_FOUND);
        }
    }
}
