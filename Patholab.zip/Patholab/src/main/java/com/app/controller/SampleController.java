
package com.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import com.app.dto.SampleDto;
import com.app.service.SampleService;

@RestController
@RequestMapping("/samples")
public class SampleController {

    @Autowired
    private SampleService sampleService;

    @PostMapping("/add")
    public ResponseEntity<?> addSample(@RequestBody @Validated SampleDto sampleDto) {
        sampleService.addSample(sampleDto);
        return new ResponseEntity<>("Sample added successfully", HttpStatus.CREATED);
    }

    @PutMapping("/update/{sampleId}")
    public ResponseEntity<?> updateSample(@PathVariable Long sampleId, @RequestBody @Validated SampleDto sampleDto) {
        sampleService.updateSample(sampleId, sampleDto);
        return new ResponseEntity<>("Sample updated successfully", HttpStatus.OK);
    }

    @GetMapping("/view/{sampleId}")
    public ResponseEntity<SampleDto> viewSample(@PathVariable Long sampleId) {
        SampleDto sampleDto = sampleService.viewSample(sampleId);
        return new ResponseEntity<>(sampleDto, HttpStatus.OK);
    }

    @DeleteMapping("/{sampleId}")
    public ResponseEntity<String> removeSample(@PathVariable Long sampleId) {
        sampleService.removeSample(sampleId);
        return ResponseEntity.ok("Sample removed successfully");
    }
}
