package com.app.controller;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.dto.BillDto;
import com.app.service.BillService;
@RestController
@RequestMapping("/bills")
public class BillController {


		@Autowired
	    private BillService billService;


	    @PostMapping
		public ResponseEntity<?> addBill(@PathVariable @NotNull Long patientId,@PathVariable @NotNull Long testId,
				@PathVariable @NotNull Long empId,@RequestBody @Valid BillDto billDto) {
		
			return ResponseEntity.status(HttpStatus.CREATED).body(billService.addBillDetails(patientId,testId,empId, billDto));
		}
	
}
