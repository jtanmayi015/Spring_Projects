package com.app.entities;

public enum SampleType 
{
	SWEAT, ORALFLUID, SALIVA, URINE, STOOL, SPUTUM, BLOOD;
}
