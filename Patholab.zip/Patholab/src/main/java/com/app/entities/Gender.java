package com.app.entities;

public enum Gender {
MALE,FEAMLE,OTHER;
}
