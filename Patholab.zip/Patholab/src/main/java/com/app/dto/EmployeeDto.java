package com.app.dto;

import com.app.entities.SampleType;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class EmployeeDto {
    private String firstName;
    private String lastName;
    private String email;
    private String password;
    private SampleType sampleType;
    private boolean isAvailable;
    private Long phoneNo;
    private Long adminId;
}
