package com.app.dto;

import java.time.LocalDate;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
@Getter
@Setter
@ToString
public class BillDto {
	private boolean isPaid;
	    private Integer amount;
	    private Long phoneNo;
	    private Long patientId;
	    private Long testId;
	    private Long empId;
	    private LocalDate collectedDate;
	    private boolean isCollected;
	    private String createdBy;
	    private String modifyBy;
}
	