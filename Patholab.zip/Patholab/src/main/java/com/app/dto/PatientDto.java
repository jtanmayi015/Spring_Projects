package com.app.dto;

import java.time.LocalDate;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import com.app.entities.Gender;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
public class PatientDto {
    
    private String patientFirstName;
    private String patientLastName;
    private Gender gender;
    private String address;
    private String phoneNo;
    private String email;
    private String password;
    private String medicalHistory;
    private LocalDate createdOn;
    private String createdBy;
    private LocalDate modifyOn;
    private String modifyBy;
    private LocalDate dateOfBirth;
    private Long empId;
}
